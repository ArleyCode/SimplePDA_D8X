//{{NO_DEPENDENCIES}}
// Microsoft eMbedded Visual C++ generated include file.
// Used by resource.rc
//
#define IDS_WND_CLASS                   1
#define IDS_APP_TITLE                   2
#define IDS_RCODE                       3
#define IDS_RLNG                        4
#define IDS_ENDINF                      5
#define IDS_MSG_HOTKEYFAIL              6
#define IDS_MSG_CONNECTFAIL             7
#define IDS_MSG_CAMERAFAIL              8
#define IDI_ICON1                       101
#define IDD_DIALOG_READBUF              104
#define IDC_EDIT_SCANDATA               1001
#define IDC_EDIT_RCODE                  1003
#define IDC_EDIT_RLNG                   1004
#define IDC_EDIT_ENDINF                 1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
